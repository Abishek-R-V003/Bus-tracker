# College Bus Tracker — Live GPS Tracking System

A real-time bus tracking web app: drivers share GPS location from their phone,
students watch the bus move live on Google Maps, admins manage the whole fleet.
Built with plain HTML/CSS/JS + Firebase (Auth + Realtime Database) + Google Maps
Platform. No build step required.

## ⚠️ About the admin account

Never hard-code an admin password in JavaScript/HTML — anyone can open
DevTools and read it. Instead, "admin" is just a **role flag** stored in the
database next to a normal Firebase Auth account:

1. Create the admin's login in the Firebase Console (Authentication → Add
   user) with whatever email/password you choose — do this in the console,
   not in code.
2. In Realtime Database, set `users/<that-user's-uid>/role` to `"admin"`.
3. The app checks that `role` field after login to decide whether to show the
   admin dashboard. The security rules (below) enforce it server-side too, so
   even a modified frontend can't fake admin access.

If a password was ever pasted into a chat, an email, or a doc, treat it as
compromised and change it before using it for real.

## 1. Firebase Setup

1. Go to https://console.firebase.google.com/ → **Add project**.
2. **Build → Authentication → Get started → Email/Password** → enable it.
3. **Build → Realtime Database → Create database** (start in **locked mode**;
   you'll paste in the rules below).
4. **Project settings → General → Your apps → Web app (</>)** → register the
   app → copy the `firebaseConfig` object.
5. Paste that config into `js/firebase-config.js` (this file holds public,
   client-safe identifiers only — Firebase web config is not a secret; access
   is controlled by the security rules, not by hiding these values).

## 2. Google Maps Platform Setup

1. https://console.cloud.google.com/ → new project (or reuse the Firebase one
   — they can share a GCP project).
2. Enable: **Maps JavaScript API, Directions API, Distance Matrix API,
   Geocoding API**.
3. Create an API key → restrict it:
   - **Application restriction:** HTTP referrers → add your GitHub
     Pages/Firebase Hosting domain(s), plus `http://localhost:*` for dev.
   - **API restriction:** limit to the four APIs above.
4. Put the key in `js/config.js` (`GOOGLE_MAPS_API_KEY`). A referrer-restricted
   browser key is designed to be public in client code — the restriction is
   what protects it, not secrecy.

## 3. Firebase Security Rules

Paste `firebase-database-rules.json` into Realtime Database → Rules, and
`firestore not used` (this project uses Realtime Database only). The rules:

- Let anyone signed in read bus/route/stop/live-location data (students need this).
- Let a driver write **only** to `liveLocations/<busId>` for the bus **they
  are assigned to** (checked against `buses/<busId>/driverId`).
- Let only `role: "admin"` users write to `buses/`, `drivers/`, `routes/`,
  `busStops/`, or manage `users/`.

## 4. Run Locally

No build tooling needed — it's static files.

```bash
npx serve .
# or
python -m http.server 5500
```

Open `index.html`. On a phone, use your machine's LAN IP so the Geolocation
API has a plausible origin (or just deploy — Geolocation requires HTTPS in
production, which both GitHub Pages and Firebase Hosting provide by default).

## 5. Deploy (Firebase Hosting — recommended, free)

```bash
npm install -g firebase-tools
firebase login
firebase init hosting   # choose this project, public dir = "." , SPA = No
firebase deploy
```

Or GitHub Pages: push this folder to a repo, enable Pages on the `main`
branch root in repo Settings → Pages.

## 6. Project Structure

```
bus-tracker/
├── index.html                 # Landing page
├── pages/
│   ├── login.html
│   ├── student.html           # Student dashboard + live map
│   ├── driver.html            # Driver dashboard + tracking control
│   └── admin.html             # Admin dashboard (buses/drivers/routes/stops)
├── css/
│   ├── design-system.css      # Tokens: colors, spacing, radius, shadows
│   └── app.css                # Layout, components, dark mode
├── js/
│   ├── config.js              # Google Maps key + app constants (public)
│   ├── firebase-config.js     # Firebase web config (public) + SDK init
│   ├── auth.js                # Login/logout/role routing
│   ├── student.js              # Student map + bus selection + ETA
│   ├── driver.js               # Geolocation watch + Firebase writes
│   ├── admin.js                # CRUD for buses/drivers/routes/stops
│   ├── eta.js                   # Distance/ETA calculation helpers
│   └── ui.js                   # Toasts, skeleton loaders, bottom sheet
├── firebase-database-rules.json
└── README.md
```

## 7. Realtime Database Shape

```
users/
  <uid>/
    name, email, role: "admin" | "driver" | "student"
    assignedBus (drivers only)
    favoriteBus, favoriteStop (students only)

drivers/
  <uid>/ name, phone, assignedBusId

students/
  <uid>/ name, email

buses/
  <busId>/ number, registration, routeId, driverId, active: true|false

routes/
  <routeId>/ name, startPoint, destination, stopIds: [...]

busStops/
  <stopId>/ name, lat, lng, order

liveLocations/
  <busId>/ latitude, longitude, speed, heading, timestamp, trackingStatus

trackingHistory/
  <busId>/
    <pushId>/ latitude, longitude, speed, timestamp
```

## 8. ETA Calculation

`js/eta.js` first tries the Google **Distance Matrix API** (bus location →
selected stop, `driving` mode) for a traffic-aware estimate; if that call
fails or is rate-limited it falls back to straight-line distance
(`google.maps.geometry.spherical`) divided by the bus's last reported speed,
so the UI never gets stuck with no answer.
