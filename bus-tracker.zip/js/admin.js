const AdminApp = (() => {
  let map, busMarkers = {};

  async function init() {
    map = new google.maps.Map(document.getElementById("admin-map"), {
      center: window.APP_CONFIG.COLLEGE_LOCATION,
      zoom: window.APP_CONFIG.DEFAULT_ZOOM,
      streetViewControl: false,
      mapTypeControl: false,
    });

    loadStats();
    loadBusTable();
    loadRecentActivity();
    watchLiveBuses();
    wireBusForm();
  }

  async function loadStats() {
    const [buses, drivers, students] = await Promise.all([
      db.ref("buses").get(),
      db.ref("drivers").get(),
      db.ref("students").get(),
    ]);
    const busList = buses.val() ? Object.values(buses.val()) : [];
    document.getElementById("stat-total-buses").textContent = busList.length;
    document.getElementById("stat-active-buses").textContent = busList.filter((b) => b.active).length;
    document.getElementById("stat-drivers").textContent = drivers.val() ? Object.keys(drivers.val()).length : 0;
    document.getElementById("stat-students").textContent = students.val() ? Object.keys(students.val()).length : 0;
  }

  async function loadBusTable() {
    const tbody = document.getElementById("bus-table-body");
    const snap = await db.ref("buses").get();
    if (!snap.exists()) {
      tbody.innerHTML = `<tr><td colspan="8" class="text-muted">No buses yet. Add one above.</td></tr>`;
      return;
    }
    const rows = [];
    snap.forEach((child) => {
      const b = child.val();
      rows.push(`
        <tr data-bus="${child.key}">
          <td>BUS ${b.number}</td>
          <td>${b.driverName || "Unassigned"}</td>
          <td>${b.routeName || "—"}</td>
          <td><span class="badge ${b.active ? "badge-live" : "badge-offline"}">${b.active ? "Active" : "Inactive"}</span></td>
          <td class="live-location">—</td>
          <td class="live-speed">—</td>
          <td class="live-eta">—</td>
          <td>
            <button class="btn-icon" onclick="AdminApp.editBus('${child.key}')">✏️</button>
            <button class="btn-icon" onclick="AdminApp.deleteBus('${child.key}')">🗑️</button>
          </td>
        </tr>`);
    });
    tbody.innerHTML = rows.join("");
  }

  function watchLiveBuses() {
    db.ref("liveLocations").on("value", (snap) => {
      if (!snap.exists()) return;
      snap.forEach((child) => {
        const busId = child.key;
        const loc = child.val();
        const pos = { lat: loc.latitude, lng: loc.longitude };

        if (busMarkers[busId]) {
          busMarkers[busId].setPosition(pos);
        } else {
          busMarkers[busId] = new google.maps.Marker({ position: pos, map, label: { text: "🚌", fontSize: "20px" } });
        }

        const row = document.querySelector(`tr[data-bus="${busId}"]`);
        if (row) {
          row.querySelector(".live-location").textContent = `${loc.latitude.toFixed(4)}, ${loc.longitude.toFixed(4)}`;
          row.querySelector(".live-speed").textContent = `${loc.speed || 0} km/h`;
        }
      });
    });
  }

  async function loadRecentActivity() {
    const list = document.getElementById("activity-list");
    // Illustrative feed derived from bus active/inactive flags; a production
    // build would log discrete events to a dedicated `activity/` node.
    const snap = await db.ref("buses").get();
    if (!snap.exists()) { list.innerHTML = `<p class="text-muted text-sm">No recent activity.</p>`; return; }
    const items = [];
    snap.forEach((child) => {
      const b = child.val();
      items.push(`<div class="activity-item">${b.active ? "🚌" : "⚪"} Bus ${b.number} is ${b.active ? "tracking live" : "currently offline"}</div>`);
    });
    list.innerHTML = items.join("");
  }

  function wireBusForm() {
    document.getElementById("add-bus-form")?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const newRef = db.ref("buses").push();
      await newRef.set({
        number: fd.get("number"),
        registration: fd.get("registration"),
        routeName: fd.get("routeName"),
        driverName: fd.get("driverName"),
        active: false,
      });
      UI.toast("Bus added", "success");
      e.target.reset();
      loadBusTable();
      loadStats();
    });
  }

  async function deleteBus(busId) {
    if (!confirm("Delete this bus? This cannot be undone.")) return;
    await db.ref(`buses/${busId}`).remove();
    await db.ref(`liveLocations/${busId}`).remove();
    UI.toast("Bus deleted", "success");
    loadBusTable();
    loadStats();
  }

  function editBus(busId) {
    UI.toast("Open the bus record to edit it (extend this modal as needed).", "info");
  }

  return { init, deleteBus, editBus };
})();
