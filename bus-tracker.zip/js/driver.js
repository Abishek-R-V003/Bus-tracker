const DriverApp = (() => {
  let map, selfMarker, watchId = null, assignedBus = null, lastPosTime = null;
  let distanceTravelledM = 0, lastPos = null;

  async function init() {
    const user = auth.currentUser;
    if (!user) return;

    const driverSnap = await db.ref(`drivers/${user.uid}`).get();
    const driverData = driverSnap.val();
    if (!driverData || !driverData.assignedBusId) {
      document.getElementById("no-bus-state").classList.remove("hidden");
      return;
    }

    const busSnap = await db.ref(`buses/${driverData.assignedBusId}`).get();
    assignedBus = { id: driverData.assignedBusId, ...busSnap.val() };
    renderBusCard();

    map = new google.maps.Map(document.getElementById("driver-map"), {
      center: window.APP_CONFIG.COLLEGE_LOCATION,
      zoom: window.APP_CONFIG.DEFAULT_ZOOM,
      streetViewControl: false,
      mapTypeControl: false,
    });

    document.getElementById("toggle-tracking-btn").addEventListener("click", toggleTracking);
    document.getElementById("emergency-btn").addEventListener("click", confirmEmergency);
  }

  function renderBusCard() {
    document.getElementById("bus-number").textContent = `Bus: ${assignedBus.registration || assignedBus.number}`;
    document.getElementById("bus-route").textContent = assignedBus.routeName || "No route assigned";
  }

  function toggleTracking() {
    if (watchId) stopTracking();
    else startTracking();
  }

  function startTracking() {
    if (!navigator.geolocation) {
      UI.toast("Geolocation not supported on this device", "error");
      return;
    }
    watchId = navigator.geolocation.watchPosition(onPosition, onPositionError, {
      enableHighAccuracy: true,
      maximumAge: 2000,
      timeout: 10000,
    });
    setTrackingUI(true);
    db.ref(`buses/${assignedBus.id}/active`).set(true);
  }

  function stopTracking() {
    if (watchId) navigator.geolocation.clearWatch(watchId);
    watchId = null;
    setTrackingUI(false);
    db.ref(`liveLocations/${assignedBus.id}/trackingStatus`).set("offline");
    db.ref(`buses/${assignedBus.id}/active`).set(false);
  }

  function setTrackingUI(active) {
    const btn = document.getElementById("toggle-tracking-btn");
    btn.textContent = active ? "⏹ STOP TRACKING" : "▶ START LIVE TRACKING";
    btn.className = active ? "btn btn-danger btn-block btn-lg" : "btn btn-success btn-block btn-lg";
    document.getElementById("gps-status").textContent = active ? "🟢 GPS Connected" : "🔴 GPS Not Connected";
    document.getElementById("tracking-status").textContent = active ? "🟢 Live Tracking Active" : "🔴 Tracking Offline";
  }

  function onPosition(pos) {
    const { latitude, longitude, speed } = pos.coords;
    const speedKmh = speed ? Math.round(speed * 3.6) : 0;
    const pointLatLng = { lat: latitude, lng: longitude };

    if (lastPos) {
      distanceTravelledM += google.maps.geometry.spherical.computeDistanceBetween(
        new google.maps.LatLng(lastPos.lat, lastPos.lng),
        new google.maps.LatLng(latitude, longitude)
      );
    }
    lastPos = pointLatLng;
    lastPosTime = Date.now();

    updateSelfMarker(pointLatLng);
    pushLocation(latitude, longitude, speedKmh);
    updateInfoCards(speedKmh);
  }

  function onPositionError(err) {
    const messages = {
      1: "Location permission denied. Enable it in your phone settings.",
      2: "Location unavailable right now.",
      3: "Location request timed out.",
    };
    UI.toast(messages[err.code] || "GPS error", "error");
    document.getElementById("gps-status").textContent = "🔴 GPS Not Connected";
  }

  function updateSelfMarker(pos) {
    if (selfMarker) {
      selfMarker.setPosition(pos);
    } else {
      selfMarker = new google.maps.Marker({ position: pos, map, label: { text: "🚌", fontSize: "22px" } });
    }
    map.panTo(pos);
  }

  function pushLocation(latitude, longitude, speedKmh) {
    db.ref(`liveLocations/${assignedBus.id}`).set({
      busId: assignedBus.id,
      driverId: auth.currentUser.uid,
      latitude,
      longitude,
      speed: speedKmh,
      timestamp: firebase.database.ServerValue.TIMESTAMP,
      trackingStatus: "online",
    });
    db.ref(`trackingHistory/${assignedBus.id}`).push({
      latitude, longitude, speed: speedKmh, timestamp: firebase.database.ServerValue.TIMESTAMP,
    });
    document.getElementById("last-updated").textContent = "Last Updated: just now";
  }

  function updateInfoCards(speedKmh) {
    document.getElementById("speed-value").textContent = `${speedKmh} km/h`;
    document.getElementById("distance-value").textContent = `${(distanceTravelledM / 1000).toFixed(1)} km`;
    // Next stop / ETA would come from comparing lastPos against the route's stop list —
    // left as a straightforward extension of the ETA module used on the student side.
  }

  function confirmEmergency() {
    if (confirm("Send an emergency alert to the admin? This should only be used in a real emergency.")) {
      db.ref(`buses/${assignedBus.id}/emergency`).set({
        active: true,
        driverId: auth.currentUser.uid,
        timestamp: firebase.database.ServerValue.TIMESTAMP,
      });
      UI.toast("Emergency alert sent to admin", "error");
    }
  }

  return { init };
})();
