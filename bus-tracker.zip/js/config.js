/**
 * Public, client-safe configuration.
 *
 * The Maps key below MUST be restricted in Google Cloud Console to your
 * deployed domain(s) + the specific APIs this app uses (see README §2).
 * A referrer-restricted browser key is meant to ship in client code — the
 * restriction is the security boundary, not secrecy.
 */
window.APP_CONFIG = {
  GOOGLE_MAPS_API_KEY: "YOUR_REFERRER_RESTRICTED_MAPS_KEY",
  COLLEGE_LOCATION: { lat: 12.5266, lng: 78.2150, name: "College Campus" }, // update to your campus
  DEFAULT_ZOOM: 13,
  LOCATION_UPDATE_INTERVAL_MS: 4000, // how often the driver push loop fires
  STALE_LOCATION_THRESHOLD_MS: 30000, // mark a bus "offline" if no update in 30s
};
