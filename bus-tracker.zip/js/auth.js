/**
 * Handles Firebase email/password auth and routes each user to the right
 * dashboard based on their `role` field in /users/<uid>. Nothing here ever
 * hard-codes a password or grants admin by checking an email string —
 * that would be trivially readable/spoofable in client code. Role is read
 * from the database and enforced server-side by the security rules.
 */
const AuthModule = (() => {
  const ROLE_REDIRECTS = {
    admin: "pages/admin.html",
    driver: "pages/driver.html",
    student: "pages/student.html",
  };

  async function login(email, password) {
    const cred = await auth.signInWithEmailAndPassword(email, password);
    const snap = await db.ref(`users/${cred.user.uid}`).get();
    if (!snap.exists()) {
      await auth.signOut();
      throw new Error("No profile found for this account. Contact your admin.");
    }
    const profile = snap.val();
    return { uid: cred.user.uid, ...profile };
  }

  async function registerStudent(name, email, password) {
    const cred = await auth.createUserWithEmailAndPassword(email, password);
    await db.ref(`users/${cred.user.uid}`).set({
      name,
      email,
      role: "student",
      createdAt: firebase.database.ServerValue.TIMESTAMP,
    });
    await db.ref(`students/${cred.user.uid}`).set({ name, email });
    return cred.user.uid;
  }

  async function resetPassword(email) {
    await auth.sendPasswordResetEmail(email);
  }

  function logout() {
    return auth.signOut();
  }

  function redirectForRole(role) {
    const target = ROLE_REDIRECTS[role];
    if (!target) {
      UI.toast("Unknown account role. Contact your admin.", "error");
      return;
    }
    window.location.href = target;
  }

  /** Call at the top of a protected page to enforce the required role. */
  function guardPage(requiredRole) {
    auth.onAuthStateChanged(async (user) => {
      if (!user) {
        window.location.href = "../pages/login.html";
        return;
      }
      const snap = await db.ref(`users/${user.uid}`).get();
      const profile = snap.val();
      if (!profile || profile.role !== requiredRole) {
        UI.toast("You don't have access to this page.", "error");
        setTimeout(() => (window.location.href = "../pages/login.html"), 1200);
      }
    });
  }

  return { login, registerStudent, resetPassword, logout, redirectForRole, guardPage };
})();
