const UI = (() => {
  function toast(message, type = "info", timeout = 3500) {
    let container = document.getElementById("toast-container");
    if (!container) {
      container = document.createElement("div");
      container.id = "toast-container";
      container.className = "toast-container";
      document.body.appendChild(container);
    }
    const el = document.createElement("div");
    el.className = `toast toast-${type}`;
    el.textContent = message;
    container.appendChild(el);
    requestAnimationFrame(() => el.classList.add("show"));
    setTimeout(() => {
      el.classList.remove("show");
      setTimeout(() => el.remove(), 300);
    }, timeout);
  }

  function skeleton(container, count = 3) {
    container.innerHTML = Array.from({ length: count })
      .map(() => `<div class="skeleton-card"></div>`)
      .join("");
  }

  function emptyState(container, icon, message) {
    container.innerHTML = `<div class="empty-state"><span class="empty-icon">${icon}</span><p>${message}</p></div>`;
  }

  function openSheet(sheetEl) {
    sheetEl.classList.remove("collapsed");
  }
  function closeSheet(sheetEl) {
    sheetEl.classList.add("collapsed");
  }

  function initSheetDrag(handleEl, sheetEl) {
    if (!handleEl) return;
    let startY = 0, dragging = false;
    handleEl.addEventListener("touchstart", (e) => { dragging = true; startY = e.touches[0].clientY; });
    handleEl.addEventListener("touchmove", (e) => {
      if (!dragging) return;
      const delta = startY - e.touches[0].clientY;
      if (delta > 30) openSheet(sheetEl);
      if (delta < -30) closeSheet(sheetEl);
    });
    handleEl.addEventListener("touchend", () => (dragging = false));
    handleEl.addEventListener("click", () =>
      sheetEl.classList.contains("collapsed") ? openSheet(sheetEl) : closeSheet(sheetEl)
    );
  }

  function initTheme() {
    const saved = localStorage.getItem("theme");
    if (saved) document.body.dataset.theme = saved;
    const btn = document.getElementById("theme-toggle-btn");
    if (btn) {
      btn.textContent = document.body.dataset.theme === "dark" ? "☀️" : "🌙";
      btn.addEventListener("click", () => {
        const isDark = document.body.dataset.theme === "dark";
        document.body.dataset.theme = isDark ? "light" : "dark";
        btn.textContent = isDark ? "🌙" : "☀️";
        localStorage.setItem("theme", document.body.dataset.theme);
      });
    }
  }

  function initBottomNav() {
    document.querySelectorAll(".bottom-nav .nav-item").forEach((item) => {
      item.addEventListener("click", () => {
        document.querySelectorAll(".bottom-nav .nav-item").forEach((i) => i.classList.remove("active"));
        item.classList.add("active");
      });
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    initTheme();
    initBottomNav();
  });

  return { toast, skeleton, emptyState, openSheet, closeSheet, initSheetDrag };
})();
