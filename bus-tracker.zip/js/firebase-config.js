/**
 * Firebase web config. These identifiers are public by design (they tell the
 * SDK which project to talk to); real access control lives in
 * firebase-database-rules.json, not in hiding these values.
 *
 * Get this object from: Firebase Console → Project settings → General →
 * Your apps → SDK setup and configuration.
 */
const firebaseConfig = {
  apiKey: "YOUR_FIREBASE_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  databaseURL: "https://YOUR_PROJECT-default-rtdb.firebaseio.com",
  projectId: "YOUR_PROJECT",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
};

firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const db = firebase.database();
