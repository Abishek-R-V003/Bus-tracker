const StudentApp = (() => {
  let map, busMarker, userMarker, routePolyline, stopMarkers = [];
  let selectedBusId = null, locationListener = null;
  let userLocation = null;

  function init() {
    map = new google.maps.Map(document.getElementById("map"), {
      center: window.APP_CONFIG.COLLEGE_LOCATION,
      zoom: window.APP_CONFIG.DEFAULT_ZOOM,
      streetViewControl: false,
      mapTypeControl: false,
    });
    Eta.init();
    locateStudent();
    loadBusList();

    document.getElementById("locate-btn")?.addEventListener("click", locateStudent);
    UI.initSheetDrag(document.getElementById("sheet-handle"), document.getElementById("bus-sheet"));

    document.getElementById("bus-search")?.addEventListener("input", (e) => {
      filterBusList(e.target.value.toLowerCase());
    });
  }

  function locateStudent() {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        userLocation = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        if (userMarker) {
          userMarker.setPosition(userLocation);
        } else {
          userMarker = new google.maps.Marker({
            position: userLocation,
            map,
            title: "You",
            icon: { path: google.maps.SymbolPath.CIRCLE, scale: 8, fillColor: "#2563eb", fillOpacity: 1, strokeColor: "#fff", strokeWeight: 2 },
          });
        }
      },
      () => UI.toast("Enable location services to see your position", "error"),
      { enableHighAccuracy: true }
    );
  }

  let allBuses = [];

  async function loadBusList() {
    const listEl = document.getElementById("bus-list");
    UI.skeleton(listEl, 4);
    const snap = await db.ref("buses").orderByChild("active").equalTo(true).get();
    if (!snap.exists()) {
      UI.emptyState(listEl, "🚍", "No buses are currently available.");
      return;
    }
    allBuses = [];
    snap.forEach((child) => allBuses.push({ id: child.key, ...child.val() }));
    renderBusList(allBuses);
  }

  function renderBusList(buses) {
    const listEl = document.getElementById("bus-list");
    if (!buses.length) {
      UI.emptyState(listEl, "🚍", "No buses match your search.");
      return;
    }
    listEl.innerHTML = buses
      .map(
        (b) => `
      <div class="card bus-card" style="margin-bottom:10px;cursor:pointer;" data-bus="${b.id}">
        <div class="bus-info">
          <h3>BUS ${b.number}</h3>
          <p class="bus-meta">${b.routeName || "Route not set"}</p>
        </div>
        <span class="badge badge-live">🟢 Live</span>
      </div>`
      )
      .join("");
    listEl.querySelectorAll("[data-bus]").forEach((card) =>
      card.addEventListener("click", () => selectBus(card.dataset.bus))
    );
  }

  function filterBusList(query) {
    const filtered = allBuses.filter(
      (b) => String(b.number).toLowerCase().includes(query) || (b.routeName || "").toLowerCase().includes(query)
    );
    renderBusList(filtered);
  }

  async function selectBus(busId) {
    selectedBusId = busId;
    const busSnap = await db.ref(`buses/${busId}`).get();
    const bus = busSnap.val();
    if (!bus) return;

    drawRoute(bus.routeId);
    watchBusLocation(busId, bus);
    UI.openSheet(document.getElementById("bus-sheet"));
  }

  async function drawRoute(routeId) {
    stopMarkers.forEach((m) => m.setMap(null));
    stopMarkers = [];
    if (routePolyline) routePolyline.setMap(null);
    if (!routeId) return;

    const routeSnap = await db.ref(`routes/${routeId}`).get();
    const route = routeSnap.val();
    if (!route || !route.stopIds) return;

    const stops = [];
    for (const stopId of route.stopIds) {
      const stopSnap = await db.ref(`busStops/${stopId}`).get();
      if (stopSnap.exists()) stops.push({ id: stopId, ...stopSnap.val() });
    }
    stops.sort((a, b) => (a.order || 0) - (b.order || 0));

    const path = stops.map((s) => ({ lat: s.lat, lng: s.lng }));
    routePolyline = new google.maps.Polyline({
      path, map, strokeColor: "#2563eb", strokeWeight: 4, strokeOpacity: 0.8,
    });

    stops.forEach((s) => {
      const marker = new google.maps.Marker({
        position: { lat: s.lat, lng: s.lng },
        map,
        title: s.name,
        icon: { path: google.maps.SymbolPath.CIRCLE, scale: 5, fillColor: "#64748b", fillOpacity: 1, strokeWeight: 0 },
      });
      marker.addListener("click", () => showEtaForStop(s));
      stopMarkers.push(marker);
    });

    window.currentRouteStops = stops;
  }

  function watchBusLocation(busId, bus) {
    if (locationListener) db.ref(`liveLocations/${selectedBusId}`).off("value", locationListener);

    locationListener = (snap) => {
      const loc = snap.val();
      renderBusSheet(bus, loc);
      if (!loc) return;

      const isStale = Date.now() - (loc.timestamp || 0) > window.APP_CONFIG.STALE_LOCATION_THRESHOLD_MS;
      const pos = { lat: loc.latitude, lng: loc.longitude };

      if (busMarker) {
        busMarker.setPosition(pos);
      } else {
        busMarker = new google.maps.Marker({
          position: pos, map,
          label: { text: "🚌", fontSize: "22px" },
          icon: { path: google.maps.SymbolPath.CIRCLE, scale: 0 }, // label-only marker
        });
      }
      if (!isStale && document.getElementById("center-on-bus")?.checked !== false) {
        map.panTo(pos);
      }
    };
    db.ref(`liveLocations/${busId}`).on("value", locationListener);
  }

  async function renderBusSheet(bus, loc) {
    const body = document.getElementById("sheet-body");
    const isLive = loc && Date.now() - (loc.timestamp || 0) < window.APP_CONFIG.STALE_LOCATION_THRESHOLD_MS;

    let etaHtml = "";
    if (isLive && window.currentRouteStops?.length) {
      const destination = window.currentRouteStops[window.currentRouteStops.length - 1];
      const eta = await Eta.getEta({ lat: loc.latitude, lng: loc.longitude }, { lat: destination.lat, lng: destination.lng }, loc.speed);
      etaHtml = `<p>Distance: <strong>${eta.distanceText}</strong></p><p>Estimated Arrival: <strong>${eta.etaMinutes} min</strong></p><p>Status: <strong>On Route</strong></p>`;
    }

    body.innerHTML = `
      <h3>BUS ${bus.number}</h3>
      <span class="badge ${isLive ? "badge-live" : "badge-offline"}">${isLive ? "🟢 Live Tracking" : "🔴 Bus is currently offline"}</span>
      <p class="text-sm text-muted" style="margin-top:8px;">Driver: ${bus.driverName || "Unassigned"}</p>
      ${etaHtml}
      <div class="flex gap-2" style="margin-top:14px;">
        <button class="btn btn-primary" id="directions-btn">Directions</button>
        <button class="btn btn-ghost" id="favorite-btn">⭐ Favorite</button>
      </div>`;

    document.getElementById("directions-btn")?.addEventListener("click", () => {
      if (!loc) return;
      window.open(`https://www.google.com/maps/dir/?api=1&destination=${loc.latitude},${loc.longitude}`, "_blank");
    });
    document.getElementById("favorite-btn")?.addEventListener("click", () => saveFavorite(bus));
  }

  async function showEtaForStop(stop) {
    if (!busMarker) return;
    const pos = busMarker.getPosition();
    const eta = await Eta.getEta({ lat: pos.lat(), lng: pos.lng() }, { lat: stop.lat, lng: stop.lng }, null);
    UI.toast(`${stop.name}: ${eta.distanceText} · ~${eta.etaMinutes} min`, "info", 4500);
  }

  async function saveFavorite(bus) {
    const user = auth.currentUser;
    if (!user) { UI.toast("Please log in", "error"); return; }
    await db.ref(`users/${user.uid}/favoriteBus`).set(bus.number);
    UI.toast("Saved to favorites", "success");
  }

  return { init };
})();
