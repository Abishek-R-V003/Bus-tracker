/**
 * Distance + ETA helpers. Tries the Distance Matrix API for a traffic-aware
 * driving estimate first; falls back to straight-line distance / last known
 * speed if that call fails, times out, or the quota is exhausted, so the UI
 * always has something to show.
 */
const Eta = (() => {
  let distanceMatrixService;

  function init() {
    distanceMatrixService = new google.maps.DistanceMatrixService();
  }

  function straightLineDistanceKm(from, to) {
    const meters = google.maps.geometry.spherical.computeDistanceBetween(
      new google.maps.LatLng(from.lat, from.lng),
      new google.maps.LatLng(to.lat, to.lng)
    );
    return meters / 1000;
  }

  function fallbackEstimate(busLocation, stop, speedKmh) {
    const distanceKm = straightLineDistanceKm(busLocation, stop);
    const effectiveSpeed = speedKmh && speedKmh > 3 ? speedKmh : 20; // assume a plausible average if stopped
    const minutes = Math.max(1, Math.round((distanceKm / effectiveSpeed) * 60));
    return {
      distanceText: `${distanceKm.toFixed(1)} km`,
      etaMinutes: minutes,
      source: "estimate",
    };
  }

  function getEta(busLocation, stop, speedKmh) {
    return new Promise((resolve) => {
      if (!distanceMatrixService) {
        resolve(fallbackEstimate(busLocation, stop, speedKmh));
        return;
      }
      distanceMatrixService.getDistanceMatrix(
        {
          origins: [busLocation],
          destinations: [stop],
          travelMode: google.maps.TravelMode.DRIVING,
          drivingOptions: { departureTime: new Date(), trafficModel: "bestguess" },
        },
        (response, status) => {
          try {
            const el = response.rows[0].elements[0];
            if (status !== "OK" || el.status !== "OK") throw new Error("no route");
            const durationSec = (el.duration_in_traffic || el.duration).value;
            resolve({
              distanceText: el.distance.text,
              etaMinutes: Math.max(1, Math.round(durationSec / 60)),
              source: "distance_matrix",
            });
          } catch (e) {
            resolve(fallbackEstimate(busLocation, stop, speedKmh));
          }
        }
      );
    });
  }

  return { init, getEta, straightLineDistanceKm };
})();
